'use strict';
/* PAE-04 CP-OFFLINE01: immutable app shell. Never accesses IndexedDB. */
const CACHE_PREFIX='pae04-ghcyber-multi03-test-cache-';
const CACHE=CACHE_PREFIX+'CPMULTI03-v062test2-offlinefix-20261117';
const RETAIN_PREVIOUS_CACHES=2;
const SHELL=new URL('./index.html',self.registration.scope).href;
const FILES=[
  './','./index.html','./app.js','./styles.css','./home.js','./home.css',
  './med_guard.mjs','./med_matcher.mjs','./med_guard.css',
  './offline_status.js',
  './manifest.webmanifest','./icons/icon.svg','./icons/apple-touch-icon.png',
  './icons/icon-192.png','./icons/icon-512.png'
];

self.addEventListener('install',event=>{
  event.waitUntil((async()=>{
    const cache=await caches.open(CACHE);
    await cache.addAll(FILES);
    // Never activate a partially cached release.
    for(const path of ['./','./index.html','./app.js','./home.js',
                       './med_guard.mjs','./offline_status.js']){
      if(!(await cache.match(new URL(path,self.registration.scope).href))){
        throw new Error('CP-OFFLINE01 missing app shell asset: '+path);
      }
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate',event=>{
  // Keep the two most recently CREATED previous app-shell caches for rollback.
  // CacheStorage.keys() is ordered by creation; static assets only, never medical data.
  // This limits eviction risk during upgrade, but full multi-tab Safari QA remains required.
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    const previous=keys.filter(key=>key.startsWith(CACHE_PREFIX)&&key!==CACHE);
    for(const key of previous.slice(0,Math.max(0,previous.length-RETAIN_PREVIOUS_CACHES))){
      await caches.delete(key);
    }
    await self.clients.claim();
  })());
});

async function matchAppShell(request){
  const cache=await caches.open(CACHE);
  const hit=await cache.match(request,{ignoreSearch:request.mode==='navigate'});
  if(hit)return hit;
  // Safari may navigate with query params or with a slash rather than index.html.
  if(request.mode==='navigate')return cache.match(SHELL);
  return undefined;
}

function offlineUnavailable(){
  return new Response(
    '<!doctype html><html lang="ru"><meta charset="utf-8">'+
    '<meta name="viewport" content="width=device-width,initial-scale=1">'+
    '<title>Офлайн-копия не готова</title>'+
    '<body style="font:18px -apple-system,system-ui;padding:25px;line-height:1.5">'+
    '<h1>Офлайн-копия ещё не готова</h1>'+
    '<p>Включите интернет, откройте Health Tracker и дождитесь сообщения '+
    '«Офлайн-копия готова» в разделе «Копии данных».</p>'+
    '<p>Не очищайте Safari и не удаляйте приложение: данные хранятся на устройстве.</p>'+
    '</body></html>',
    {status:503,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}}
  );
}

self.addEventListener('fetch',event=>{
  const request=event.request;
  const url=new URL(request.url);
  const scope=new URL(self.registration.scope);
  if(request.method!=='GET'||url.origin!==scope.origin||!url.pathname.startsWith(scope.pathname))return;
  event.respondWith((async()=>{
    try{
      const hit=await matchAppShell(request);
      if(hit)return hit;
    }catch(_cacheError){
      // WebKit can occasionally reject a Cache API operation; do not
      // propagate the rejection directly through respondWith().
    }
    try{
      return await fetch(request);
    }catch(_networkError){
      if(request.mode==='navigate'){
        try{
          const fallback=await matchAppShell(new Request(SHELL,{mode:'same-origin'}));
          if(fallback)return fallback;
        }catch(_cacheError){}
        return offlineUnavailable();
      }
      return Response.error();
    }
  })());
});
